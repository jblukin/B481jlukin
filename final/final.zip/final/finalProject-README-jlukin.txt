B481 / Fall 2023 / Final Project / Jonah Lukin - jlukin

Files Included (.cs, .shader, .mat, .cginc, .scene)

 - Note: Some names are 2 files with different types -
 
MainScene

DragObject

CreateCube

PointLightAMaterial

PointLightBMaterial

BaseShader

CubeMaterial

CubeShader

TerrainMaterial

TerrainShader

TextureMappingMaterial

TextureMapping

CameraOperations

TerrainGenerator

NoiseGenerator (Unused)


All Parts Completed